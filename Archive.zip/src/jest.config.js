module.exports = {
  name: 'server-database',
  displayName: 'server-database',
  rootDir: './../',
  testMatch: [
    '<rootDir>/src/server.test.js'
  ],
  testEnvironment: 'node'
};